/*
Programmer: Mason Larcombe s0257989
File: Week1
Date: 09/03/2017
Purpose: COIT11222 assignment one question one for Term 1 2017
using println to print initials (ML) in asterisks.
*/
public class Week1
{
    public static void main(String[] args)
    {
        System.out.println("*     *  *");				//Outputs the following "*" pattern
        System.out.println("**   **  *");
        System.out.println("* * * *  *");
        System.out.println("*  *  *  *");
        System.out.println("*     *  *");
        System.out.println("*     *  *");
        System.out.println("*     *  *******");
    }
}
