package bmi.calculator;
public class BmiCalculator {
    public static void main(String[] args){
        bmi.view.BMIView gui = new bmi.view.BMIView();
        gui.setVisible(true);    
    }
}